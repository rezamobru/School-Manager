
// fix menu after scolling
function menuscroll() {
  var $navmenu = $('.bottom-nav');
  if ($(window).scrollTop() > 150) {
    $navmenu.addClass('NavFix');
  } else if ($(window).scrollTop() < 15) {
    $navmenu.removeClass("NavFix");
  }
}
menuscroll();
$(window).on('scroll', function () {
  menuscroll();
});

//  Back top

$(window).scroll(function () {
  if ($(this).scrollTop() > 200) {
    $('.go-top').fadeIn(200);
  } else {
    $('.go-top').fadeOut(200);
  }
});
// Animate the scroll to top
$('.go-top').click(function (event) {
  event.preventDefault();
  $('html, body').animate({ scrollTop: 0 }, 300);
});
// search filter
$(document).ready(function(){
  $("#myInput").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myTable tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });

});

$(document).ready(()=>{
  $(function() {
  $('#date-man').datepicker({
       changeMonth: true,
       changeYear: true
   });
});
$(function() {
  $('#date-man-2').datepicker({
       changeMonth: true,
       changeYear: true
   });
});
});
function changeborder(id){
  $("#"+id).css({"border":"2px solid green"});

}
// styles for home.html

function logout() {
  if (confirm("آیا میخواهید خارج شوید؟") == true)
    window.location.href = "index.html";
  else return false;
}


$(()=>{
  $('.close-dialog').on('click',()=>{
   $('.bg-black').hide();
    $('.new-user-modal').hide();
  });
});
function passShow() {
  var x = document.getElementById("password");
  if (x.type === "password") {
    x.type = "text";
  } else {
    x.type = "password";
  }
}

function viewPass() {
  var z = document.getElementById('password2');
  if (z.type === "password") {
    z.type = "text";
  } else {
    z.type = "password";
  }
}
// user info
$('.setting-modal').draggable();
$('.modal-box').draggable();
// $('.new-user-modal').draggable();
$(".passShow").on("click", () => {
  $(".passShow").toggleClass("fa-eye-slash", "fa-eye");
});
$(".showPass").on("click", () => {
  $(".showPass").toggleClass("fa-eye-slash", "fa-eye");
});
// for making tooltip for every link menu
$(function () {
  $('[data-toggle="tooltip"]').tooltip();
});


var screen_height = $(window).height();
var screen_height_without_nav = screen_height - 60;
document.getElementById('iframe').style.height = screen_height_without_nav + "px";
$(window).on('resize',()=>{
// alert('window is resized');
var screen_height2 = $(window).height();
var screen_height_without_nav2 = screen_height2 - 60;
// var sidebar = $('#right-menu').css("height");
document.getElementById("right_menu").style.height = screen_height_without_nav2 + "px";
document.getElementById('iframe').style.height = screen_height_without_nav + "px";
});
$(function () {
$('[data-toggle="tooltip"]').tooltip();
});
$(()=>{

  $("li#setting-menu").click(()=>{
    $('.user-poup-menu').hide();
  });
$("#user-pic").on("click", () => {
  $('.res_menu').hide();
  $('.bg-black').fadeIn();
  $("#user-poup-menu").toggle();
  });
  $('.bg-black').click(()=>{ 
  $("#user-poup-menu").hide(); 
  $('.bg-black').hide();
  });
});

function setlocalStoage(){
  var dollor = $("#dollor").val();
  var yoro = $("#yoro").val();
  var kaldar = $("#kaldar").val();
  var toman = $("#toman").val();

  if(dollor == ""){

  }else{
    localStorage.setItem(1,dollor);
  }
  if(yoro == ""){

  }else{
    localStorage.setItem(2,yoro);
  }
  if(kaldar == ""){

  }else{
    localStorage.setItem(3,kaldar);
  }
  if(toman == ""){

  }else{
    localStorage.setItem(4,toman);
  }
  
}
  
$(()=>{
  $('.btnCr').click(()=>{
    $('body').append('  <div class="alert alert-success  alert-dismissible fade show" role="alert"> '+ '<h3 style="text-align: center; font-size: 20px;">نرخ اسعار با موفقیت ذخیره شد</h3> '+
     '<button type="button" class="close" style="position: absolute; left: 1px !important;" '+ 'data-dismiss="alert" aria-label="Close">'+
     '   <span aria-hidden="true">&times;</span>' +
      '</button> '+
    ' </div>');
    $('.bg-black').fadeOut(2200);
    $('.exchange_currency_div').animate({
      right: '-80%',
    },200);
    $('.alert-success').show().fadeOut(2200);
    // $('.bg-black').fadeOut(3800);
    });
  });

  $(document).ready(()=>{
    $(function() {
    $('#date_man').datepicker({
         changeMonth: true,
         changeYear: true
     });
  });
});



function setlocalStoage(){
var owner_name = $("#owner_name").val();
var owner_detail1 = $("#owner_detail1").val();
var owner_detail2 = $("#owner_detail2").val();
localStorage.setItem(5,owner_name);
localStorage.setItem(6,owner_detail1);
localStorage.setItem(7,owner_detail2);

}
$('#owner_name').val(localStorage.getItem(5));
$('#owner_detail1').val(localStorage.getItem(6));
$('#owner_detail2').val(localStorage.getItem(7));
// alert(localStorage.getItem(7));
$('#total-show').val();
$('#quantity-show').on('keyup',()=>{
    $('#total-show').val($('#quantity-show').val()-$('#reciept-show').val()); 
});
$('#reciept-show').on('keyup',()=>{
    $('#total-show').val($('#quantity-show').val()-$('#reciept-show').val()); 
});

// alert('hello')
      //owl carousel
      $(document).ready(function() {
          $("#owl-demo").owlCarousel({
              navigation : true,
              slideSpeed : 300,
              paginationSpeed : 400,
              singleItem : true

          });
      });
      //custom select box
      $(function(){
          $('select.styled').customSelect();
      });

      var count = 1;
      $("#item-search").on("search",function(){
          
           var html_code = "<tr id='row_id_"+count+"'>";

                html_code+=
                '<td>'+count+'</td>';
                html_code+=
                '<td><input type="text" name="item" class="form-control item" id="item"></td>';
                html_code+=
                '<td><input type="number" name="quantity"  class="form-control quantity" id="quantity_'+count+'"></td>';
                html_code+=
                '<td><input type="number" name="price" class="form-control price" id="price_'+count+'"></td>';
                html_code+=
                '<td><input type="number" name="total" readonly class="form-control total" id="total_'+count+'"></td>';
                html_code+=
                '<td class="print"><span class="delete-img print"  id="'+count+'" ><img width="25px" style="cursor: pointer;" src="assets/img/mawadkham/trash.svg" alt=""></span></td>';
                html_code += "</tr>";
                
                $("#tbody").append(html_code);
                count++;
      });

      $(()=>{
        //   $('.item-search').on('keyup',(e)=>{
        //   });
        price.on('keyup',()=>{

      total.val(price.val() + quantity.val());
        });
        quantity.on('keyup',()=>{
          
            total.val(price.val() + quantity.val());
        });
      });
      $(document).on('click','.delete-img',function(){
          var row_id = $(this).attr("id");
          $("#row_id_"+row_id).remove();
      });
      $(document).on('keyup','.quantity',function(){
        total_cal(count);
      });
       function total_cal(count){
        var total_price =0;
        for(var x=1;x<=count;x++){
            var row_id_quantity = $('#quantity_'+x).val();
            if(row_id_quantity > 0){    
                var row_id_price = $('#price_'+x).val();
                var actual_amount = row_id_quantity*row_id_price;
                
                $('#total_'+x).val(actual_amount);
            }
        }
       }
      $(document).on('keyup','.price',function(){
                    total_cal(count);

                  });
$(()=>{
  $('.toggoleBtn').click(()=>{
    $('.right_menu_text').show();
    $('.right_menu_text').animate({right:50},500);
    $('.toggoleBtn').hide();
    $('.closeToggle').show();
    $('iframe').animate({
      right:'190px'
    },500);
    // $('iframe').css('transition','500ms');
    
  });
  $('.closeToggle').click(()=>{
    $('.right_menu_text').animate({right:-500},500);
    $('.toggoleBtn').show();
    $('.closeToggle').hide();
    $('iframe').animate({
      right:'50px'
    },500);
    $('window').on('resize',()=>{
      $('.right_menu_text').hid();
      $('iframe').css('right','0');
    });
  });
  $('.btn_logout').click(() => {
    // alert('hello');
    window.location.href = 'index.html';
  });
  $('.open_res_menu').click(()=>{
    $('.res_menu').slideToggle();
  });
  $(window).on('resize',()=>{
    $('.res_menu').hide();
  }); 

  $('.menu-bg').click((e)=>{
    $('.toggoleBtn').hide();
    $('.closeToggle').show();
    $('.right_menu_text').animate({right:50},50);
    e.preventDefault();
        $('iframe').animate({
      right:'150'
    },500);
  });
});
    $(document).ready(function(){
    $('.list-menu').click(function(){
      if($(this).attr('aria-expanded') == 'false'){
        $('.list-submenu').slideUp();
        $(this).next().slideToggle();
        $('.list-menu').attr('aria-expanded','true');
        $(this).attr('arror','down');
      // $('.right_menu_text ul li i').toggleClass('fa-angle-left','fa-angle-right');
      } else {
        // $('.list-submenu').slideUp();
        $(this).next().slideToggle();
        $('.list-menu').attr('aria-expanded','false');
      // $('.right_menu_text ul li i').child().css('transform','rotate(0deg)');
      }
    });
    $(".res_menu ul ul li").click(function(){
      $(this).slideUp();
      $('.res_menu').slideUp();
    });
  });